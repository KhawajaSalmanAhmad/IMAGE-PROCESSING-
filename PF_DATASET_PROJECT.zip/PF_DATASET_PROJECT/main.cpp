#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cstdio> 

using namespace std;

// ==========================================
// GLOBAL POINTERS FOR DATASET MANAGEMENT
// ==========================================
int numTypes = 0;
string uniqueTypes[10]; // Standard array (No dynamic strings!)
int* imagesPerType = nullptr; // Dynamic Ints ONLY
int**** dataset = nullptr;  
int** imageRows = nullptr;  
int** imageCols = nullptr;  

bool isDatasetLoaded = false;

// ==========================================
// CORE FUNCTIONALITIES
// ==========================================

void loadDataset() {
    ifstream metaFile("dataset.txt");
    if (!metaFile.is_open()) {
        cout << "Error: Could not open dataset.txt. Check your folder structure!" << endl;
        return;
    }

    string path, type;
    int totalLines = 0;
    
    while (metaFile >> path) totalLines++;
    
    metaFile.clear();
    metaFile.seekg(0, ios::beg);

    // Dynamic Int Array
    imagesPerType = new int[totalLines];
    for (int i = 0; i < totalLines; i++) *(imagesPerType + i) = 0;
    numTypes = 0;
    
    while (metaFile >> path) {
        int slashPos = -1;
        for (int i = 0; i < path.length(); i++) {
            if (path[i] == '/' || path[i] == '\\') {
                slashPos = i; break;
            }
        }

        if (slashPos != -1) type = path.substr(0, slashPos);
        else type = "unknown";

        bool found = false;
        for (int i = 0; i < numTypes; i++) {
            if (uniqueTypes[i] == type) { // Standard array access
                (*(imagesPerType + i))++;
                found = true; break;
            }
        }
        
        if (!found) {
            uniqueTypes[numTypes] = type; 
            *(imagesPerType + numTypes) = 1;
            numTypes++;
        }
    }
    
    // Dynamic Int Arrays ONLY
    dataset = new int***[numTypes];
    imageRows = new int*[numTypes];
    imageCols = new int*[numTypes];

    for (int t = 0; t < numTypes; t++) {
        int imgCount = *(imagesPerType + t);
        *(dataset + t) = new int**[imgCount];
        *(imageRows + t) = new int[imgCount];
        *(imageCols + t) = new int[imgCount];
    }

    metaFile.clear();
    metaFile.seekg(0, ios::beg);
    
    int* currentTypeIndex = new int[numTypes];
    for (int i = 0; i < numTypes; i++) *(currentTypeIndex + i) = 0;

    cout << "Reading PGM files and building 4D structure..." << endl;

    while (metaFile >> path) {
        int slashPos = -1;
        for (int i = 0; i < path.length(); i++) {
            if (path[i] == '/' || path[i] == '\\') { slashPos = i; break; }
        }

        if (slashPos != -1) type = path.substr(0, slashPos);
        else type = "unknown";

        int t = 0;
        for (; t < numTypes; t++) if (uniqueTypes[t] == type) break;

        int imgIndex = *(currentTypeIndex + t);

        ifstream imgFile(path);
        if (!imgFile.is_open()) {
            cout << "Warning: Could not open image " << path << endl;
            (*(currentTypeIndex + t))++;
            continue;
        }

        string magic; imgFile >> magic; 
        char peek = imgFile.peek();
        while (peek == ' ' || peek == '\n' || peek == '\r') {
            imgFile.get(); peek = imgFile.peek();
        }
        if (peek == '#') { string comment; getline(imgFile, comment); }

        int width, height, maxVal;
        imgFile >> width >> height >> maxVal;

        *(*(imageRows + t) + imgIndex) = height;
        *(*(imageCols + t) + imgIndex) = width;
        *(*(dataset + t) + imgIndex) = new int*[height];

        for (int r = 0; r < height; r++) {
            *(*(*(dataset + t) + imgIndex) + r) = new int[width];
            for (int c = 0; c < width; c++) {
                int pixelValue; imgFile >> pixelValue;
                *(*(*(*(dataset + t) + imgIndex) + r) + c) = pixelValue;
            }
        }
        imgFile.close();
        (*(currentTypeIndex + t))++; 
    }
    
    delete[] currentTypeIndex;
    metaFile.close();
    
    isDatasetLoaded = true;
    cout << "-> Dataset successfully loaded and parsed!" << endl;
}

void addOrDeleteImage() {
    if (!isDatasetLoaded) {
        cout << "Error: The dataset is empty. Please load the dataset first (Option 1)." << endl;
        return;
    }

    int subChoice;
    cout << "\n--- Add or Delete Image ---" << endl;
    cout << "1. Synthetically Generate & Add Image (Rubric 6.1.11)" << endl;
    cout << "2. Permanently Delete Image (Rubric 6.1.10)" << endl;
    cout << "Enter your choice: ";
    cin >> subChoice;

    if (subChoice == 1) {
        string type;
        cout << "Enter folder to generate image for (xray, ct_scan, nature, cars): ";
        cin >> type;

        int t = -1;
        for (int i = 0; i < numTypes; i++) {
            if (uniqueTypes[i] == type) { t = i; break; }
        }

        if (t == -1) {
            cout << "Error: Folder '" << type << "' not found!" << endl; return;
        }

        int width = 50 + (rand() % 51);
        int height = 50 + (rand() % 51);
        string newPath = type + "/generated_" + to_string(rand() % 100000) + ".pgm";

        ofstream newFile(newPath);
        if (!newFile.is_open()) {
            cout << "Error: Could not create file " << newPath << endl; return;
        }

        newFile << "P2\n# Synthetically generated\n" << width << " " << height << "\n255\n";

        // Dynamic allocation using INT
        int** newImage = new int*[height];
        for (int r = 0; r < height; r++) {
            *(newImage + r) = new int[width];
            for (int c = 0; c < width; c++) {
                int p = 0;
                if (type == "xray") p = rand() % 100;
                else if (type == "ct_scan") p = (rand() % 2 == 0) ? rand() % 50 : 200 + (rand() % 56);
                else if (type == "nature") p = 80 + (rand() % 100);
                else if (type == "cars") p = rand() % 256;

                *(*(newImage + r) + c) = p;
                newFile << p << " ";
            }
            newFile << "\n";
        }
        newFile.close();

        ofstream appFile("dataset.txt", ios::app);
        appFile << newPath << "\n";
        appFile.close();

        int oldCount = *(imagesPerType + t);
        int newCount = oldCount + 1;
        
        // Dynamic arrays using INT
        int*** newDatasetT = new int**[newCount];
        int* newRows = new int[newCount];
        int* newCols = new int[newCount];

        for (int i = 0; i < oldCount; i++) {
            *(newDatasetT + i) = *(*(dataset + t) + i);
            *(newRows + i) = *(*(imageRows + t) + i);
            *(newCols + i) = *(*(imageCols + t) + i);
        }

        *(newDatasetT + oldCount) = newImage;
        *(newRows + oldCount) = height;
        *(newCols + oldCount) = width;

        delete[] *(dataset + t); delete[] *(imageRows + t); delete[] *(imageCols + t);
        *(dataset + t) = newDatasetT; *(imageRows + t) = newRows; *(imageCols + t) = newCols; *(imagesPerType + t) = newCount;

        cout << "-> Successfully generated and saved " << newPath << "!" << endl;

    } else if (subChoice == 2) {
        string type;
        cout << "Enter folder to delete from (e.g., cars, xray): ";
        cin >> type;

        int t = -1;
        for (int i = 0; i < numTypes; i++) {
            if (uniqueTypes[i] == type) { t = i; break; }
        }

        if (t == -1) { cout << "Error: Folder not found!" << endl; return; }

        int oldCount = *(imagesPerType + t);
        if (oldCount == 0) { cout << "Error: No images left!" << endl; return; }

        cout << "Enter index to delete (0 to " << oldCount - 1 << "): ";
        int delIndex; cin >> delIndex;

        if (delIndex < 0 || delIndex >= oldCount) { cout << "Error: Invalid index!" << endl; return; }

        string targetPath = "";
        int currentIdx = 0;
        ifstream inFile("dataset.txt");
        ofstream tempFile("temp.txt");
        string pathStr;
        
        while (inFile >> pathStr) {
            string folder = pathStr.substr(0, pathStr.find('/'));
            if (folder == type) {
                if (currentIdx == delIndex) {
                    targetPath = pathStr; 
                    currentIdx++;
                    continue; 
                }
                currentIdx++;
            }
            tempFile << pathStr << "\n";
        }
        inFile.close(); tempFile.close();

        remove("dataset.txt");
        rename("temp.txt", "dataset.txt");

        if (targetPath != "") {
            if (remove(targetPath.c_str()) == 0) {
                cout << "-> Physical file " << targetPath << " permanently deleted." << endl;
            } else {
                cout << "-> Warning: Could not delete physical file. It may be missing." << endl;
            }
        }

        int delRows = *(*(imageRows + t) + delIndex);
        for (int r = 0; r < delRows; r++) delete[] *(*(*(dataset + t) + delIndex) + r);
        delete[] *(*(dataset + t) + delIndex);

        int newCount = oldCount - 1;
        int*** newDatasetT = new int**[newCount];
        int* newRows = new int[newCount];
        int* newCols = new int[newCount];

        int j = 0;
        for (int i = 0; i < oldCount; i++) {
            if (i == delIndex) continue; 
            *(newDatasetT + j) = *(*(dataset + t) + i);
            *(newRows + j) = *(*(imageRows + t) + i);
            *(newCols + j) = *(*(imageCols + t) + i);
            j++;
        }

        delete[] *(dataset + t); delete[] *(imageRows + t); delete[] *(imageCols + t);
        *(dataset + t) = newDatasetT; *(imageRows + t) = newRows; *(imageCols + t) = newCols; *(imagesPerType + t) = newCount;

        cout << "-> Image fully deleted from RAM, hard drive, and dataset.txt!" << endl;

    } else {
        cout << "Invalid choice!" << endl;
    }
}

void viewDatasetStatistics() {
    if (!isDatasetLoaded) { cout << "Error: Load dataset first." << endl; return; }
    int totalImages = 0;
    cout << "\n--- Dataset Statistics ---" << endl;
    for (int t = 0; t < numTypes; t++) {
        cout << "Type: " << uniqueTypes[t] << " -> " << *(imagesPerType + t) << " images" << endl;
        totalImages += *(imagesPerType + t);
    }
    cout << "Total Images in Dataset: " << totalImages << "\n" << endl;
}

void minMaxAnalysis() {
    if (!isDatasetLoaded) { cout << "Error: Load dataset first." << endl; return; }
    int maxVal = *(imagesPerType + 0); int minVal = *(imagesPerType + 0);
    for (int i = 1; i < numTypes; i++) {
        if (*(imagesPerType + i) > maxVal) maxVal = *(imagesPerType + i);
        if (*(imagesPerType + i) < minVal) minVal = *(imagesPerType + i);
    }
    cout << "\nMaximum Images (" << maxVal << "): ";
    for (int i = 0; i < numTypes; i++) if (*(imagesPerType + i) == maxVal) cout << uniqueTypes[i] << " ";
    cout << "\nMinimum Images (" << minVal << "): ";
    for (int i = 0; i < numTypes; i++) if (*(imagesPerType + i) == minVal) cout << uniqueTypes[i] << " ";
    cout << "\n" << endl;
}

void processImages() {
    if (!isDatasetLoaded) { cout << "Error: Load dataset first." << endl; return; }
    int subChoice;
    cout << "\n--- Process --- \n1. Normalize\n2. Invert\n3. Brightness\nChoice: "; cin >> subChoice;
    
    for (int t = 0; t < numTypes; t++) {
        for (int i = 0; i < *(imagesPerType + t); i++) {
            int rows = *(*(imageRows + t) + i); int cols = *(*(imageCols + t) + i);
            if (subChoice == 1) { 
                int cMin = 255, cMax = 0;
                for (int r = 0; r < rows; r++) {
                    for (int c = 0; c < cols; c++) {
                        int p = *(*(*(*(dataset + t) + i) + r) + c);
                        if (p < cMin) cMin = p; if (p > cMax) cMax = p;
                    }
                }
                if (cMax > cMin) {
                    for (int r = 0; r < rows; r++) {
                        for (int c = 0; c < cols; c++) {
                            int p = *(*(*(*(dataset + t) + i) + r) + c);
                            *(*(*(*(dataset + t) + i) + r) + c) = ((p - cMin) * 255) / (cMax - cMin); 
                        }
                    }
                }
            } else if (subChoice == 2) {
                for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) *(*(*(*(dataset + t) + i) + r) + c) = 255 - *(*(*(*(dataset + t) + i) + r) + c);
            } else if (subChoice == 3) {
                for (int r = 0; r < rows; r++) {
                    for (int c = 0; c < cols; c++) {
                        int np = *(*(*(*(dataset + t) + i) + r) + c) + 50;
                        *(*(*(*(dataset + t) + i) + r) + c) = (np > 255) ? 255 : np;
                    }
                }
            }
        }
    }
    cout << "-> Processing applied!" << endl;
}

void saveDataset() {
    if (!isDatasetLoaded) { cout << "Error: Load dataset first." << endl; return; }
    cout << "Saving processed images..." << endl;
    for (int t = 0; t < numTypes; t++) {
        for (int i = 0; i < *(imagesPerType + t); i++) {
            string filename = uniqueTypes[t] + "/processed_img_" + to_string(i) + ".pgm";
            ofstream outFile(filename);
            if (!outFile.is_open()) continue;
            int rows = *(*(imageRows + t) + i); int cols = *(*(imageCols + t) + i);
            outFile << "P2\n" << cols << " " << rows << "\n255\n"; 
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) outFile << *(*(*(*(dataset + t) + i) + r) + c) << " ";
                outFile << "\n";
            }
            outFile.close();
        }
    }
    cout << "-> All files saved!" << endl;
}

void cleanupMemory() {
    if (!isDatasetLoaded) return;
    for (int t = 0; t < numTypes; t++) {
        for (int i = 0; i < *(imagesPerType + t); i++) {
            for (int r = 0; r < *(*(imageRows + t) + i); r++) delete[] *(*(*(dataset + t) + i) + r);
            delete[] *(*(dataset + t) + i);
        }
        delete[] *(dataset + t); delete[] *(imageRows + t); delete[] *(imageCols + t);
    }
    // Only dynamically allocated Int arrays get deleted!
    delete[] dataset; delete[] imageRows; delete[] imageCols; delete[] imagesPerType; 
}

int main() {
    srand(time(0)); 
    int choice = 0;
    cout << "\n*** RUNNING NEW VERSION 8.1 (INT DYNAMIC ALLOCATION ONLY) ***\n" << endl;
    while (choice != 7) {
        cout << "\n=========================================\n1. Load dataset\n2. Add/Delete (Rubric 6.1.10)\n3. View stats\n4. Min/Max analysis\n5. Process images\n6. Save\n7. Exit\nChoice: ";
        cin >> choice;
        switch (choice) {
            case 1: if (!isDatasetLoaded) loadDataset(); else cout << "Already loaded!" << endl; break;
            case 2: addOrDeleteImage(); break;
            case 3: viewDatasetStatistics(); break;
            case 4: minMaxAnalysis(); break;
            case 5: processImages(); break;
            case 6: saveDataset(); break;
            case 7: cleanupMemory(); break;
        }
    }
    return 0;
}
